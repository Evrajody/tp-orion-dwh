#!/usr/bin/env python3
"""
Generateur du package SSIS Orion_Pipeline_Quotidien.dtsx.

Pourquoi un generateur plutot qu'un .dtsx ecrit a la main : un .dtsx full
fidelity fait ~5000 lignes XML et exige des refId/lineageId/DTSID coherents
entre composants. Un generateur garde cette coherence et permet de modifier
schemas/requetes sans editer du XML.

Sortie : ssis/Orion_Pipeline_Quotidien.dtsx
"""

from __future__ import annotations

import datetime as _dt
import os
import uuid
from dataclasses import dataclass, field
from typing import Iterable

HERE = os.path.dirname(os.path.abspath(__file__))
OUT  = os.path.join(HERE, "Orion_Pipeline_Quotidien.dtsx")

# Pas de randomisation : on veut un dtsx reproductible (diff propre, regenerable).
# uuid5 sur un namespace fixe = GUID stable par cle logique.
_NS = uuid.UUID("11111111-1111-1111-1111-111111111111")

def guid(*parts: str) -> str:
    return "{" + str(uuid.uuid5(_NS, "/".join(parts))).upper() + "}"

# ----- Colonnes ----------------------------------------------------------------

@dataclass
class Col:
    name: str
    dt: str                 # ssis dataType: i2 i4 i8 bool wstr str dbDate dbTimeStamp numeric
    length: int = 0
    precision: int = 0
    scale: int = 0
    code_page: int = 0

    def attrs(self) -> str:
        parts = [f'dataType="{self.dt}"']
        if self.length:
            parts.append(f'length="{self.length}"')
        if self.precision:
            parts.append(f'precision="{self.precision}"')
        if self.scale:
            parts.append(f'scale="{self.scale}"')
        if self.code_page:
            parts.append(f'codePage="{self.code_page}"')
        return " ".join(parts)


# ----- Definition des DFT -----------------------------------------------------

@dataclass
class DFT:
    name: str
    source_kind: str        # "odbc" ou "oledb"
    source_cm: str          # ref du Connection Manager source
    dest_cm: str
    sql: str                # requete source
    dest_table: str         # ex "[staging].[canal]"
    columns: list[Col]      # colonnes mappees (auto-map)
    fast_load: bool = True


# Notes types :
# - ODBC depuis Postgres : INT->i4, BIGINT->i8, SMALLINT->i2, BOOLEAN->bool,
#   VARCHAR/CHAR/TEXT->wstr (le pilote psqlODBC renvoie Unicode), DATE->dbDate,
#   TIMESTAMP->dbTimeStamp, NUMERIC(p,s)->numeric.
# - OLE DB depuis SQL Server (lecture OrionETL) : meme mapping, NVARCHAR->wstr,
#   CHAR(n)->str avec codePage 1252.
# - Cote destination : meme regles que cote source, length doit matcher la colonne.

STAGING_DFTS: list[DFT] = [
    DFT(
        name="DFT_Staging_Geographie",
        source_kind="odbc", source_cm="ORION_PG_OLTP_CM",
        dest_cm="OrionETL_CM",
        sql=(
            "SELECT v.ville_id, v.nom_ville, v.code_postal, "
            "r.nom_region, p.code_pays, p.nom_pays, c.nom_continent "
            "FROM ops.ville v "
            "JOIN ops.region r ON r.region_id = v.region_id "
            "JOIN ops.pays p ON p.pays_id = r.pays_id "
            "JOIN ops.continent c ON c.continent_id = p.continent_id"
        ),
        dest_table="[staging].[geographie_full]",
        columns=[
            Col("ville_id", "i4"),
            Col("nom_ville", "wstr", length=100),
            Col("code_postal", "wstr", length=20),
            Col("nom_region", "wstr", length=100),
            Col("code_pays", "wstr", length=2),
            Col("nom_pays", "wstr", length=100),
            Col("nom_continent", "wstr", length=50),
        ],
    ),
    DFT(
        name="DFT_Staging_Fournisseur",
        source_kind="odbc", source_cm="ORION_PG_OLTP_CM",
        dest_cm="OrionETL_CM",
        sql=(
            "SELECT f.fournisseur_id, f.nom_fournisseur, "
            "p.nom_pays, c.nom_continent "
            "FROM ops.fournisseur f "
            "JOIN ops.pays p ON p.pays_id = f.pays_id "
            "JOIN ops.continent c ON c.continent_id = p.continent_id"
        ),
        dest_table="[staging].[fournisseur_full]",
        columns=[
            Col("fournisseur_id", "i4"),
            Col("nom_fournisseur", "wstr", length=120),
            Col("nom_pays", "wstr", length=100),
            Col("nom_continent", "wstr", length=50),
        ],
    ),
    DFT(
        name="DFT_Staging_Canal",
        source_kind="odbc", source_cm="ORION_PG_OLTP_CM",
        dest_cm="OrionETL_CM",
        sql="SELECT canal_id, code_canal, nom_canal FROM ops.canal_vente",
        dest_table="[staging].[canal]",
        columns=[
            Col("canal_id", "i2"),
            Col("code_canal", "wstr", length=20),
            Col("nom_canal", "wstr", length=50),
        ],
    ),
    DFT(
        name="DFT_Staging_Produit",
        source_kind="odbc", source_cm="ORION_PG_OLTP_CM",
        dest_cm="OrionETL_CM",
        sql=(
            "SELECT pr.produit_id, pr.nom_produit, g.nom_groupe_produit, "
            "cat.nom_categorie_produit, lp.nom_ligne_produit, "
            "f.fournisseur_id AS fournisseur_id_naturel, f.nom_fournisseur, pr.actif "
            "FROM ops.produit pr "
            "JOIN ops.groupe_produit g ON g.groupe_produit_id = pr.groupe_produit_id "
            "JOIN ops.categorie_produit cat ON cat.categorie_produit_id = g.categorie_produit_id "
            "JOIN ops.ligne_produit lp ON lp.ligne_produit_id = cat.ligne_produit_id "
            "JOIN ops.fournisseur f ON f.fournisseur_id = pr.fournisseur_id"
        ),
        dest_table="[staging].[produit_full]",
        columns=[
            Col("produit_id", "i8"),
            Col("nom_produit", "wstr", length=150),
            Col("nom_groupe_produit", "wstr", length=100),
            Col("nom_categorie_produit", "wstr", length=100),
            Col("nom_ligne_produit", "wstr", length=100),
            Col("fournisseur_id_naturel", "i4"),
            Col("nom_fournisseur", "wstr", length=120),
            Col("actif", "bool"),
        ],
    ),
    DFT(
        name="DFT_Staging_Client",
        source_kind="odbc", source_cm="ORION_PG_OLTP_CM",
        dest_cm="OrionETL_CM",
        sql=(
            "SELECT c.client_id, "
            "c.nom || ' ' || c.prenom AS nom_complet, "
            "c.sexe, c.date_naissance, "
            "gc.nom_groupe_client AS groupe_client, "
            "(cf.carte_fidelite_id IS NOT NULL) AS a_carte_fidelite, "
            "v.nom_ville, p.nom_pays, cont.nom_continent, c.maj_le "
            "FROM ops.client c "
            "LEFT JOIN ops.groupe_client gc ON gc.groupe_client_id = c.groupe_client_id "
            "LEFT JOIN ops.carte_fidelite cf ON cf.client_id = c.client_id "
            "JOIN ops.ville v ON v.ville_id = c.ville_id "
            "JOIN ops.region r ON r.region_id = v.region_id "
            "JOIN ops.pays p ON p.pays_id = r.pays_id "
            "JOIN ops.continent cont ON cont.continent_id = p.continent_id"
        ),
        dest_table="[staging].[client_full]",
        columns=[
            Col("client_id", "i8"),
            Col("nom_complet", "wstr", length=161),
            Col("sexe", "wstr", length=1),
            Col("date_naissance", "dbDate"),
            Col("groupe_client", "wstr", length=80),
            Col("a_carte_fidelite", "bool"),
            Col("nom_ville", "wstr", length=100),
            Col("nom_pays", "wstr", length=100),
            Col("nom_continent", "wstr", length=50),
            Col("maj_le", "dbTimeStamp"),
        ],
    ),
    DFT(
        name="DFT_Staging_Employe",
        source_kind="odbc", source_cm="ORION_PG_OLTP_CM",
        dest_cm="OrionETL_CM",
        sql=(
            "SELECT e.employe_id, "
            "e.nom || ' ' || e.prenom AS nom_complet, "
            "e.sexe, e.date_naissance, e.salaire, "
            "op.nom_org_pays AS org_pays, "
            "oc.nom_org_compagnie AS org_compagnie, "
            "od.nom_org_departement AS org_departement, "
            "os.nom_org_section AS org_section, "
            "og.nom_org_groupe AS org_groupe, "
            "(m.nom || ' ' || m.prenom) AS nom_manager, "
            "e.date_embauche, e.date_depart, "
            "cc.type_contrat AS type_contrat_courant, "
            "cc.date_debut AS date_debut_contrat, "
            "cc.date_fin AS date_fin_contrat, "
            "CASE WHEN cc.contrat_id IS NULL THEN 'SansContrat' "
            "WHEN cc.date_fin IS NULL THEN 'Actif' "
            "WHEN cc.date_fin >= CURRENT_DATE THEN 'Actif' "
            "ELSE 'Expire' END AS statut_contrat, "
            "(SELECT COUNT(*) FROM ops.contrat_employe ce "
            "WHERE ce.employe_id = e.employe_id) AS nb_contrats_signes, "
            "e.maj_le "
            "FROM ops.employe e "
            "JOIN ops.org_groupe og ON og.org_groupe_id = e.org_groupe_id "
            "JOIN ops.org_section os ON os.org_section_id = og.org_section_id "
            "JOIN ops.org_departement od ON od.org_departement_id = os.org_departement_id "
            "JOIN ops.org_compagnie oc ON oc.org_compagnie_id = od.org_compagnie_id "
            "JOIN ops.org_pays op ON op.org_pays_id = oc.org_pays_id "
            "LEFT JOIN ops.employe m ON m.employe_id = e.manager_id "
            "LEFT JOIN LATERAL ("
            "SELECT contrat_id, type_contrat, date_debut, date_fin "
            "FROM ops.contrat_employe ce "
            "WHERE ce.employe_id = e.employe_id "
            "ORDER BY (date_fin IS NULL) DESC, date_debut DESC LIMIT 1"
            ") cc ON TRUE"
        ),
        dest_table="[staging].[employe_full]",
        columns=[
            Col("employe_id", "i8"),
            Col("nom_complet", "wstr", length=161),
            Col("sexe", "wstr", length=1),
            Col("date_naissance", "dbDate"),
            Col("salaire", "numeric", precision=12, scale=2),
            Col("org_pays", "wstr", length=50),
            Col("org_compagnie", "wstr", length=100),
            Col("org_departement", "wstr", length=100),
            Col("org_section", "wstr", length=100),
            Col("org_groupe", "wstr", length=100),
            Col("nom_manager", "wstr", length=161),
            Col("date_embauche", "dbDate"),
            Col("date_depart", "dbDate"),
            Col("type_contrat_courant", "wstr", length=30),
            Col("date_debut_contrat", "dbDate"),
            Col("date_fin_contrat", "dbDate"),
            Col("statut_contrat", "wstr", length=20),
            Col("nb_contrats_signes", "i8"),
            Col("maj_le", "dbTimeStamp"),
        ],
    ),
    DFT(
        name="DFT_Staging_Lignes_Commande",
        source_kind="odbc", source_cm="ORION_PG_OLTP_CM",
        dest_cm="OrionETL_CM",
        sql=(
            "SELECT o.commande_id, l.numero_ligne, o.date_commande, "
            "o.client_id, o.employe_id, o.canal_id, l.produit_id, "
            "p.fournisseur_id, c.ville_id AS cli_ville_id, "
            "l.quantite, l.prix_unitaire, l.cout_unitaire, l.pct_remise "
            "FROM ops.commande o "
            "JOIN ops.ligne_commande l ON l.commande_id = o.commande_id "
            "JOIN ops.produit p ON p.produit_id = l.produit_id "
            "JOIN ops.client c ON c.client_id = o.client_id "
            "WHERE o.date_commande > ?"
        ),
        dest_table="[staging].[lignes_commande]",
        columns=[
            Col("commande_id", "i8"),
            Col("numero_ligne", "i2"),
            Col("date_commande", "dbDate"),
            Col("client_id", "i8"),
            Col("employe_id", "i8"),
            Col("canal_id", "i2"),
            Col("produit_id", "i8"),
            Col("fournisseur_id", "i4"),
            Col("cli_ville_id", "i4"),
            Col("quantite", "numeric", precision=12, scale=3),
            Col("prix_unitaire", "numeric", precision=12, scale=2),
            Col("cout_unitaire", "numeric", precision=12, scale=2),
            Col("pct_remise", "numeric", precision=5, scale=4),
        ],
    ),
]


DWH_DFTS: list[DFT] = [
    DFT(
        name="DFT_DWH_DimDate",
        source_kind="oledb", source_cm="OrionETL_CM",
        dest_cm="OrionDWH_CM",
        sql=(
            "SELECT cle_date, date_complete, jour_du_mois, numero_mois, "
            "nom_mois, numero_trimestre, annee, jour_de_semaine, nom_jour, "
            "semaine_annee, est_weekend, saison FROM dim.dim_date"
        ),
        dest_table="[dw].[dim_date]",
        columns=[
            Col("cle_date", "i4"),
            Col("date_complete", "dbDate"),
            Col("jour_du_mois", "i2"),
            Col("numero_mois", "i2"),
            Col("nom_mois", "wstr", length=12),
            Col("numero_trimestre", "i2"),
            Col("annee", "i2"),
            Col("jour_de_semaine", "i2"),
            Col("nom_jour", "wstr", length=12),
            Col("semaine_annee", "i2"),
            Col("est_weekend", "bool"),
            Col("saison", "wstr", length=10),
        ],
    ),
    DFT(
        name="DFT_DWH_DimCanal",
        source_kind="oledb", source_cm="OrionETL_CM",
        dest_cm="OrionDWH_CM",
        sql="SELECT canal_id, code_canal, nom_canal FROM dim.dim_canal",
        dest_table="[dw].[dim_canal]",
        columns=[
            Col("canal_id", "i2"),
            Col("code_canal", "wstr", length=20),
            Col("nom_canal", "wstr", length=50),
        ],
    ),
    DFT(
        name="DFT_DWH_DimGeographie",
        source_kind="oledb", source_cm="OrionETL_CM",
        dest_cm="OrionDWH_CM",
        sql=(
            "SELECT ville_id, nom_ville, nom_region, code_pays, nom_pays, "
            "nom_continent, code_postal FROM dim.dim_geographie"
        ),
        dest_table="[dw].[dim_geographie]",
        columns=[
            Col("ville_id", "i4"),
            Col("nom_ville", "wstr", length=100),
            Col("nom_region", "wstr", length=100),
            Col("code_pays", "str", length=2, code_page=1252),
            Col("nom_pays", "wstr", length=100),
            Col("nom_continent", "wstr", length=50),
            Col("code_postal", "wstr", length=20),
        ],
    ),
    DFT(
        name="DFT_DWH_DimFournisseur",
        source_kind="oledb", source_cm="OrionETL_CM",
        dest_cm="OrionDWH_CM",
        sql=(
            "SELECT fournisseur_id, nom_fournisseur, nom_pays, nom_continent "
            "FROM dim.dim_fournisseur"
        ),
        dest_table="[dw].[dim_fournisseur]",
        columns=[
            Col("fournisseur_id", "i4"),
            Col("nom_fournisseur", "wstr", length=120),
            Col("nom_pays", "wstr", length=100),
            Col("nom_continent", "wstr", length=50),
        ],
    ),
    DFT(
        name="DFT_DWH_DimProduit",
        source_kind="oledb", source_cm="OrionETL_CM",
        dest_cm="OrionDWH_CM",
        sql=(
            "SELECT produit_id, nom_produit, nom_groupe_produit, "
            "nom_categorie_produit, nom_ligne_produit, fournisseur_id_naturel, "
            "nom_fournisseur, actif, maj_le FROM dim.dim_produit"
        ),
        dest_table="[dw].[dim_produit]",
        columns=[
            Col("produit_id", "i8"),
            Col("nom_produit", "wstr", length=150),
            Col("nom_groupe_produit", "wstr", length=100),
            Col("nom_categorie_produit", "wstr", length=100),
            Col("nom_ligne_produit", "wstr", length=100),
            Col("fournisseur_id_naturel", "i4"),
            Col("nom_fournisseur", "wstr", length=120),
            Col("actif", "bool"),
            Col("maj_le", "dbTimeStamp2", scale=3),
        ],
    ),
    DFT(
        name="DFT_DWH_DimClient",
        source_kind="oledb", source_cm="OrionETL_CM",
        dest_cm="OrionDWH_CM",
        sql=(
            "SELECT client_id, nom_complet, sexe, tranche_age, groupe_client, "
            "a_carte_fidelite, nom_ville, nom_pays, nom_continent, "
            "effectif_du, effectif_au, est_courant, hash_ligne FROM dim.dim_client"
        ),
        dest_table="[dw].[dim_client]",
        columns=[
            Col("client_id", "i8"),
            Col("nom_complet", "wstr", length=160),
            Col("sexe", "str", length=1, code_page=1252),
            Col("tranche_age", "wstr", length=20),
            Col("groupe_client", "wstr", length=80),
            Col("a_carte_fidelite", "bool"),
            Col("nom_ville", "wstr", length=100),
            Col("nom_pays", "wstr", length=100),
            Col("nom_continent", "wstr", length=50),
            Col("effectif_du", "dbDate"),
            Col("effectif_au", "dbDate"),
            Col("est_courant", "bool"),
            Col("hash_ligne", "str", length=64, code_page=1252),
        ],
    ),
    DFT(
        name="DFT_DWH_DimEmploye",
        source_kind="oledb", source_cm="OrionETL_CM",
        dest_cm="OrionDWH_CM",
        sql=(
            "SELECT employe_id, nom_complet, sexe, tranche_age, salaire, "
            "tranche_salaire, org_pays, org_compagnie, org_departement, "
            "org_section, org_groupe, nom_manager, date_embauche, date_depart, "
            "type_contrat_courant, date_debut_contrat, date_fin_contrat, "
            "statut_contrat, nb_contrats_signes, effectif_du, effectif_au, "
            "est_courant, hash_ligne FROM dim.dim_employe"
        ),
        dest_table="[dw].[dim_employe]",
        columns=[
            Col("employe_id", "i8"),
            Col("nom_complet", "wstr", length=160),
            Col("sexe", "str", length=1, code_page=1252),
            Col("tranche_age", "wstr", length=20),
            Col("salaire", "numeric", precision=12, scale=2),
            Col("tranche_salaire", "wstr", length=20),
            Col("org_pays", "wstr", length=50),
            Col("org_compagnie", "wstr", length=100),
            Col("org_departement", "wstr", length=100),
            Col("org_section", "wstr", length=100),
            Col("org_groupe", "wstr", length=100),
            Col("nom_manager", "wstr", length=160),
            Col("date_embauche", "dbDate"),
            Col("date_depart", "dbDate"),
            Col("type_contrat_courant", "wstr", length=30),
            Col("date_debut_contrat", "dbDate"),
            Col("date_fin_contrat", "dbDate"),
            Col("statut_contrat", "wstr", length=20),
            Col("nb_contrats_signes", "i4"),
            Col("effectif_du", "dbDate"),
            Col("effectif_au", "dbDate"),
            Col("est_courant", "bool"),
            Col("hash_ligne", "str", length=64, code_page=1252),
        ],
    ),
    DFT(
        name="DFT_DWH_FaitVentes",
        source_kind="oledb", source_cm="OrionETL_CM",
        dest_cm="OrionDWH_CM",
        sql=(
            "SELECT cle_date, cle_produit, cle_client, cle_employe, "
            "cle_fournisseur, cle_canal, cle_geographie_client, commande_id, "
            "numero_ligne, quantite, prix_unitaire, cout_unitaire, pct_remise, "
            "montant_brut, montant_remise, montant_net, montant_cout, "
            "montant_marge FROM fact.fait_ventes"
        ),
        dest_table="[dw].[fait_ventes]",
        columns=[
            Col("cle_date", "i4"),
            Col("cle_produit", "i8"),
            Col("cle_client", "i8"),
            Col("cle_employe", "i8"),
            Col("cle_fournisseur", "i8"),
            Col("cle_canal", "i2"),
            Col("cle_geographie_client", "i8"),
            Col("commande_id", "i8"),
            Col("numero_ligne", "i2"),
            Col("quantite", "numeric", precision=12, scale=3),
            Col("prix_unitaire", "numeric", precision=12, scale=2),
            Col("cout_unitaire", "numeric", precision=12, scale=2),
            Col("pct_remise", "numeric", precision=5, scale=4),
            Col("montant_brut", "numeric", precision=14, scale=2),
            Col("montant_remise", "numeric", precision=14, scale=2),
            Col("montant_net", "numeric", precision=14, scale=2),
            Col("montant_cout", "numeric", precision=14, scale=2),
            Col("montant_marge", "numeric", precision=14, scale=2),
        ],
    ),
]


# ----- Generation XML ----------------------------------------------------------

def xml_escape(s: str) -> str:
    return (
        s.replace("&", "&amp;")
         .replace("<", "&lt;")
         .replace(">", "&gt;")
         .replace('"', "&quot;")
    )


# Compteur global de lineageId — incremente a chaque colonne creee.
_lineage = [10]
def next_lineage() -> int:
    _lineage[0] += 1
    return _lineage[0]


def cm_xml() -> str:
    """Connection Managers niveau package."""
    parts = []

    # ODBC vers Postgres
    parts.append(f'''  <DTS:ConnectionManager
    DTS:refId="Package.ConnectionManagers[ORION_PG_OLTP_CM]"
    DTS:CreationName="ODBC"
    DTS:DTSID="{guid("cm", "ORION_PG_OLTP_CM")}"
    DTS:ObjectName="ORION_PG_OLTP_CM"
    DTS:Description="ODBC vers Postgres OLTP via DSN ORION_PG_OLTP">
    <DTS:ObjectData>
      <DTS:ConnectionManager
        DTS:ConnectionString="Dsn=ORION_PG_OLTP" />
    </DTS:ObjectData>
  </DTS:ConnectionManager>''')

    # OLE DB OrionETL
    parts.append(f'''  <DTS:ConnectionManager
    DTS:refId="Package.ConnectionManagers[OrionETL_CM]"
    DTS:CreationName="OLEDB"
    DTS:DTSID="{guid("cm", "OrionETL_CM")}"
    DTS:ObjectName="OrionETL_CM"
    DTS:Description="OLE DB vers la base OrionETL (localhost)">
    <DTS:ObjectData>
      <DTS:ConnectionManager
        DTS:ConnectionString="Data Source=localhost;Initial Catalog=OrionETL;Provider=MSOLEDBSQL;Integrated Security=SSPI;Auto Translate=False;" />
    </DTS:ObjectData>
  </DTS:ConnectionManager>''')

    # OLE DB OrionDWH
    parts.append(f'''  <DTS:ConnectionManager
    DTS:refId="Package.ConnectionManagers[OrionDWH_CM]"
    DTS:CreationName="OLEDB"
    DTS:DTSID="{guid("cm", "OrionDWH_CM")}"
    DTS:ObjectName="OrionDWH_CM"
    DTS:Description="OLE DB vers la base OrionDWH (localhost)">
    <DTS:ObjectData>
      <DTS:ConnectionManager
        DTS:ConnectionString="Data Source=localhost;Initial Catalog=OrionDWH;Provider=MSOLEDBSQL;Integrated Security=SSPI;Auto Translate=False;" />
    </DTS:ObjectData>
  </DTS:ConnectionManager>''')

    return "\n".join(parts)


def variables_xml() -> str:
    """Variables niveau package."""
    return f'''  <DTS:Variables>
    <DTS:Variable
      DTS:CreationName=""
      DTS:DataType="7"
      DTS:DTSID="{guid("var", "Watermark")}"
      DTS:Namespace="User"
      DTS:ObjectName="Watermark">
      <DTS:VariableValue DTS:DataType="7">1900-01-01T00:00:00</DTS:VariableValue>
    </DTS:Variable>
    <DTS:Variable
      DTS:CreationName=""
      DTS:DataType="20"
      DTS:DTSID="{guid("var", "LignesIn")}"
      DTS:Namespace="User"
      DTS:ObjectName="LignesIn">
      <DTS:VariableValue DTS:DataType="20">0</DTS:VariableValue>
    </DTS:Variable>
    <DTS:Variable
      DTS:CreationName=""
      DTS:DataType="20"
      DTS:DTSID="{guid("var", "LignesOut")}"
      DTS:Namespace="User"
      DTS:ObjectName="LignesOut">
      <DTS:VariableValue DTS:DataType="20">0</DTS:VariableValue>
    </DTS:Variable>
  </DTS:Variables>'''


def sql_task_xml(parent_ref: str, name: str, cm_name: str, sql: str,
                 result_set: str = "None",
                 result_bindings: list[tuple[str, str]] | None = None,
                 ) -> str:
    """Execute SQL Task.

    result_set : 'None' (0), 'SingleRow' (2), 'FullResultSet' (3)
    result_bindings : liste de (result_name, variable_qualified_name)
    """
    rs_code = {"None": "0", "SingleRow": "2", "FullResultSet": "3"}[result_set]
    ref_id = f"{parent_ref}\\{name}"
    cm_ref = f"Package.ConnectionManagers[{cm_name}]"
    bindings = ""
    if result_bindings:
        items = []
        for rn, var in result_bindings:
            items.append(f'''            <SQLTask:ResultBinding SQLTask:ResultName="{rn}" SQLTask:DtsVariableName="{var}" />''')
        bindings = f'''
{chr(10).join(items)}'''

    return f'''      <DTS:Executable
        DTS:refId="{ref_id}"
        DTS:CreationName="Microsoft.ExecuteSQLTask"
        DTS:Description="Execute SQL Task"
        DTS:DTSID="{guid("exec", ref_id)}"
        DTS:ExecutableType="Microsoft.ExecuteSQLTask"
        DTS:LocaleID="-1"
        DTS:ObjectName="{name}"
        DTS:TaskContact="Execute SQL Task; Microsoft Corporation; SQL Server; (c) Microsoft Corporation; All Rights Reserved;https://www.microsoft.com/sql/support/default.asp;1">
        <DTS:Variables />
        <DTS:ObjectData>
          <SQLTask:SqlTaskData
            xmlns:SQLTask="www.microsoft.com/sqlserver/dts/tasks/sqltask"
            SQLTask:Connection="{guid("cm", cm_name)}"
            SQLTask:SqlStatementSource="{xml_escape(sql)}"
            SQLTask:ResultType="{rs_code}">{bindings}
          </SQLTask:SqlTaskData>
        </DTS:ObjectData>
      </DTS:Executable>'''


def precedence_xml(parent_ref: str, from_name: str, to_name: str,
                   logical_and: bool = True,
                   value: int = 0) -> str:
    """Precedence Constraint.

    value : 0 = Success (vert), 1 = Failure (rouge), 2 = Completion (bleu)
    """
    from_ref = f"{parent_ref}\\{from_name}"
    to_ref   = f"{parent_ref}\\{to_name}"
    pc_name  = f"PC_{from_name}_to_{to_name}"
    return f'''      <DTS:PrecedenceConstraint
        DTS:refId="{parent_ref}.PrecedenceConstraints[{pc_name}]"
        DTS:CreationName=""
        DTS:DTSID="{guid("pc", parent_ref, from_name, to_name)}"
        DTS:From="{from_ref}"
        DTS:LogicalAnd="{'True' if logical_and else 'False'}"
        DTS:ObjectName="{pc_name}"
        DTS:To="{to_ref}"
        DTS:Value="{value}" />'''


def odbc_source_component(dft_ref: str, dft: DFT) -> str:
    """Composant ODBC Source dans une DFT."""
    comp_ref = f"{dft_ref}\\ODBC Source"
    cm_ref   = f"Package.ConnectionManagers[{dft.source_cm}]"

    # Generer outputColumns + externalMetadataColumns
    out_cols = []
    ext_cols = []
    for col in dft.columns:
        lin = next_lineage()
        ext_id = next_lineage()
        out_cols.append(
            f'''              <outputColumn
                refId="{comp_ref}.Outputs[ODBC Source Output].Columns[{col.name}]"
                {col.attrs()}
                errorOrTruncationOperation="Conversion"
                errorRowDisposition="FailComponent"
                externalMetadataColumnId="{comp_ref}.Outputs[ODBC Source Output].ExternalColumns[{col.name}]"
                lineageId="{comp_ref}.Outputs[ODBC Source Output].Columns[{col.name}]"
                name="{col.name}"
                truncationRowDisposition="FailComponent" />'''
        )
        ext_cols.append(
            f'''              <externalMetadataColumn
                refId="{comp_ref}.Outputs[ODBC Source Output].ExternalColumns[{col.name}]"
                {col.attrs()}
                name="{col.name}" />'''
        )

    error_out_cols = []
    for col in dft.columns:
        error_out_cols.append(
            f'''              <outputColumn
                refId="{comp_ref}.Outputs[ODBC Source Error Output].Columns[{col.name}]"
                {col.attrs()}
                lineageId="{comp_ref}.Outputs[ODBC Source Error Output].Columns[{col.name}]"
                name="{col.name}" />'''
        )

    # Si requete parametree (presence d'un ?), proprietes additionnelles
    has_param = "?" in dft.sql
    param_prop = ""
    if has_param:
        # Lier Parameter0 a User::Watermark via parameterMapping
        param_prop = '''
            <property
              dataType="System.String"
              description="Parameter Mapping"
              name="ParameterMapping">"Parameter0:Input",{''' + guid("var", "Watermark") + '''};</property>'''

    return f'''        <component
          refId="{comp_ref}"
          componentClassID="Microsoft.SqlServer.Dts.Pipeline.OdbcSourceAdapter, Microsoft.SqlServer.OdbcSrcDest, Version=16.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91"
          contactInfo="ODBC Source;Microsoft Corporation; Microsoft SQL Server; (C) Microsoft Corporation; All Rights Reserved; http://www.microsoft.com/sql/support;2"
          description="ODBC Source"
          name="ODBC Source"
          usesDispositions="true"
          version="2">
          <properties>
            <property
              dataType="System.Int32"
              description="The number of seconds the driver will wait for query results."
              name="CommandTimeout">0</property>
            <property
              dataType="System.String"
              description="The name of the table or view to be accessed by this component."
              name="TableName"></property>
            <property
              dataType="System.String"
              description="The SQL command to be executed."
              name="SqlCommand"
              UITypeEditor="Microsoft.DataTransformationServices.Controls.ModalMultilineStringEditor, Microsoft.DataTransformationServices.Controls, Version=16.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91">{xml_escape(dft.sql)}</property>
            <property
              dataType="System.Int32"
              description="Specifies the mode used to access the database."
              name="AccessMode"
              typeConverter="AccessMode">2</property>
            <property
              dataType="System.Int32"
              description="The number of rows in each batch."
              name="BatchSize">0</property>
            <property
              dataType="System.Int32"
              description="The kind of statement to execute (1=Direct/text, 2=Procedure)."
              name="StatementType">1</property>
            <property
              dataType="System.Int32"
              description="Whether to use bound parameters."
              name="BindCharColumnAs"
              typeConverter="BindCharColumnAs">2</property>{param_prop}
          </properties>
          <connections>
            <connection
              refId="{comp_ref}.Connections[OdbcConnection]"
              connectionManagerID="{cm_ref}"
              connectionManagerRefId="{cm_ref}"
              description="The ODBC runtime connection used to access the database."
              name="OdbcConnection" />
          </connections>
          <outputs>
            <output
              refId="{comp_ref}.Outputs[ODBC Source Output]"
              name="ODBC Source Output">
              <outputColumns>
{chr(10).join(out_cols)}
              </outputColumns>
              <externalMetadataColumns isUsed="True">
{chr(10).join(ext_cols)}
              </externalMetadataColumns>
            </output>
            <output
              refId="{comp_ref}.Outputs[ODBC Source Error Output]"
              isErrorOut="true"
              name="ODBC Source Error Output">
              <outputColumns>
{chr(10).join(error_out_cols)}
                <outputColumn
                  refId="{comp_ref}.Outputs[ODBC Source Error Output].Columns[ErrorCode]"
                  dataType="i4"
                  lineageId="{comp_ref}.Outputs[ODBC Source Error Output].Columns[ErrorCode]"
                  name="ErrorCode"
                  specialFlags="1" />
                <outputColumn
                  refId="{comp_ref}.Outputs[ODBC Source Error Output].Columns[ErrorColumn]"
                  dataType="i4"
                  lineageId="{comp_ref}.Outputs[ODBC Source Error Output].Columns[ErrorColumn]"
                  name="ErrorColumn"
                  specialFlags="2" />
              </outputColumns>
            </output>
          </outputs>
        </component>'''


def oledb_source_component(dft_ref: str, dft: DFT) -> str:
    """Composant OLE DB Source."""
    comp_ref = f"{dft_ref}\\OLE DB Source"
    cm_ref   = f"Package.ConnectionManagers[{dft.source_cm}]"

    out_cols = []
    ext_cols = []
    for col in dft.columns:
        out_cols.append(
            f'''              <outputColumn
                refId="{comp_ref}.Outputs[OLE DB Source Output].Columns[{col.name}]"
                {col.attrs()}
                errorOrTruncationOperation="Conversion"
                errorRowDisposition="FailComponent"
                externalMetadataColumnId="{comp_ref}.Outputs[OLE DB Source Output].ExternalColumns[{col.name}]"
                lineageId="{comp_ref}.Outputs[OLE DB Source Output].Columns[{col.name}]"
                name="{col.name}"
                truncationRowDisposition="FailComponent" />'''
        )
        ext_cols.append(
            f'''              <externalMetadataColumn
                refId="{comp_ref}.Outputs[OLE DB Source Output].ExternalColumns[{col.name}]"
                {col.attrs()}
                name="{col.name}" />'''
        )

    error_out_cols = []
    for col in dft.columns:
        error_out_cols.append(
            f'''              <outputColumn
                refId="{comp_ref}.Outputs[OLE DB Source Error Output].Columns[{col.name}]"
                {col.attrs()}
                lineageId="{comp_ref}.Outputs[OLE DB Source Error Output].Columns[{col.name}]"
                name="{col.name}" />'''
        )

    return f'''        <component
          refId="{comp_ref}"
          componentClassID="Microsoft.OLEDBSource"
          contactInfo="OLE DB Source;Microsoft Corporation; Microsoft SQL Server; (C) Microsoft Corporation; All Rights Reserved; http://www.microsoft.com/sql/support;7"
          description="OLE DB Source"
          name="OLE DB Source"
          usesDispositions="true"
          version="7">
          <properties>
            <property
              dataType="System.Int32"
              description="The number of seconds before a command times out."
              name="CommandTimeout">0</property>
            <property
              dataType="System.String"
              description="Specifies the name of the database object used to open a rowset."
              name="OpenRowset"></property>
            <property
              dataType="System.String"
              description="Variable that contains the name of the database object used to open a rowset."
              name="OpenRowsetVariable"></property>
            <property
              dataType="System.String"
              description="SQL command to be executed."
              name="SqlCommand"
              UITypeEditor="Microsoft.DataTransformationServices.Controls.ModalMultilineStringEditor, Microsoft.DataTransformationServices.Controls, Version=16.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91">{xml_escape(dft.sql)}</property>
            <property
              dataType="System.String"
              description="Variable that contains the SQL command to be executed."
              name="SqlCommandVariable"></property>
            <property
              dataType="System.Int32"
              description="Specifies the column code page to use when code page information is unavailable from the data source."
              name="DefaultCodePage">1252</property>
            <property
              dataType="System.Boolean"
              description="Forces the use of the DefaultCodePage property value when describing character data."
              name="AlwaysUseDefaultCodePage">false</property>
            <property
              dataType="System.Int32"
              description="Specifies the mode used to access the database (0=table/view, 2=SqlCommand, 3=OpenRowset variable)."
              name="AccessMode"
              typeConverter="AccessMode">2</property>
            <property
              dataType="System.String"
              description="The mappings between the parameters in the SQL command and variables."
              name="ParameterMapping"></property>
          </properties>
          <connections>
            <connection
              refId="{comp_ref}.Connections[OleDbConnection]"
              connectionManagerID="{cm_ref}"
              connectionManagerRefId="{cm_ref}"
              description="The OLE DB runtime connection used to access the database."
              name="OleDbConnection" />
          </connections>
          <outputs>
            <output
              refId="{comp_ref}.Outputs[OLE DB Source Output]"
              name="OLE DB Source Output">
              <outputColumns>
{chr(10).join(out_cols)}
              </outputColumns>
              <externalMetadataColumns isUsed="True">
{chr(10).join(ext_cols)}
              </externalMetadataColumns>
            </output>
            <output
              refId="{comp_ref}.Outputs[OLE DB Source Error Output]"
              isErrorOut="true"
              name="OLE DB Source Error Output">
              <outputColumns>
{chr(10).join(error_out_cols)}
                <outputColumn
                  refId="{comp_ref}.Outputs[OLE DB Source Error Output].Columns[ErrorCode]"
                  dataType="i4"
                  lineageId="{comp_ref}.Outputs[OLE DB Source Error Output].Columns[ErrorCode]"
                  name="ErrorCode"
                  specialFlags="1" />
                <outputColumn
                  refId="{comp_ref}.Outputs[OLE DB Source Error Output].Columns[ErrorColumn]"
                  dataType="i4"
                  lineageId="{comp_ref}.Outputs[OLE DB Source Error Output].Columns[ErrorColumn]"
                  name="ErrorColumn"
                  specialFlags="2" />
              </outputColumns>
            </output>
          </outputs>
        </component>'''


def oledb_destination_component(dft_ref: str, dft: DFT, src_name: str) -> str:
    """Composant OLE DB Destination."""
    comp_ref = f"{dft_ref}\\OLE DB Destination"
    cm_ref   = f"Package.ConnectionManagers[{dft.dest_cm}]"
    src_comp_ref = f"{dft_ref}\\{src_name}"
    src_output   = f"{src_comp_ref}.Outputs[{src_name} Output]"

    input_cols = []
    ext_cols   = []
    for col in dft.columns:
        input_cols.append(
            f'''              <inputColumn
                refId="{comp_ref}.Inputs[OLE DB Destination Input].Columns[{col.name}]"
                cachedDataType="{col.dt}"'''
            + (f' cachedLength="{col.length}"' if col.length else '')
            + (f' cachedPrecision="{col.precision}"' if col.precision else '')
            + (f' cachedScale="{col.scale}"' if col.scale else '')
            + (f' cachedCodePage="{col.code_page}"' if col.code_page else '')
            + f'''
                cachedName="{col.name}"
                externalMetadataColumnId="{comp_ref}.Inputs[OLE DB Destination Input].ExternalColumns[{col.name}]"
                lineageId="{src_output}.Columns[{col.name}]" />'''
        )
        ext_cols.append(
            f'''              <externalMetadataColumn
                refId="{comp_ref}.Inputs[OLE DB Destination Input].ExternalColumns[{col.name}]"
                {col.attrs()}
                name="{col.name}" />'''
        )

    fast_load = 'true' if dft.fast_load else 'false'
    fast_options = "TABLOCK,CHECK_CONSTRAINTS" if dft.fast_load else ""

    return f'''        <component
          refId="{comp_ref}"
          componentClassID="Microsoft.OLEDBDestination"
          contactInfo="OLE DB Destination;Microsoft Corporation; Microsoft SQL Server; (C) Microsoft Corporation; All Rights Reserved; http://www.microsoft.com/sql/support;4"
          description="OLE DB Destination"
          name="OLE DB Destination"
          usesDispositions="true"
          version="4">
          <properties>
            <property
              dataType="System.Int32"
              description="The number of seconds before a command times out."
              name="CommandTimeout">0</property>
            <property
              dataType="System.String"
              description="Specifies the name of the database object used to open a rowset."
              name="OpenRowset">{xml_escape(dft.dest_table)}</property>
            <property
              dataType="System.String"
              description="Variable that contains the name of the database object used to open a rowset."
              name="OpenRowsetVariable"></property>
            <property
              dataType="System.String"
              description="SQL command to be executed."
              name="SqlCommand"
              UITypeEditor="Microsoft.DataTransformationServices.Controls.ModalMultilineStringEditor, Microsoft.DataTransformationServices.Controls, Version=16.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91"></property>
            <property
              dataType="System.Int32"
              description="The default code page to use."
              name="DefaultCodePage">1252</property>
            <property
              dataType="System.Boolean"
              description="Always use the default code page."
              name="AlwaysUseDefaultCodePage">false</property>
            <property
              dataType="System.Int32"
              description="Specifies the access mode (0=table/view, 1=table/view from variable, 3=table/view fast load, 4=fast load from variable, 2=SqlCommand)."
              name="AccessMode"
              typeConverter="AccessMode">3</property>
            <property
              dataType="System.Boolean"
              description="Specifies whether identity columns can be inserted."
              name="FastLoadKeepIdentity">false</property>
            <property
              dataType="System.Boolean"
              description="Specifies whether columns containing null values are inserted as null."
              name="FastLoadKeepNulls">false</property>
            <property
              dataType="System.String"
              description="Fast load options."
              name="FastLoadOptions">{fast_options}</property>
            <property
              dataType="System.Int32"
              description="Maximum number of rows committed in a single batch."
              name="FastLoadMaxInsertCommitSize">2147483647</property>
          </properties>
          <connections>
            <connection
              refId="{comp_ref}.Connections[OleDbConnection]"
              connectionManagerID="{cm_ref}"
              connectionManagerRefId="{cm_ref}"
              description="The OLE DB runtime connection used to access the database."
              name="OleDbConnection" />
          </connections>
          <inputs>
            <input
              refId="{comp_ref}.Inputs[OLE DB Destination Input]"
              errorOrTruncationOperation="Insert"
              errorRowDisposition="FailComponent"
              hasSideEffects="true"
              name="OLE DB Destination Input"
              truncationRowDisposition="FailComponent">
              <inputColumns>
{chr(10).join(input_cols)}
              </inputColumns>
              <externalMetadataColumns isUsed="True">
{chr(10).join(ext_cols)}
              </externalMetadataColumns>
            </input>
          </inputs>
          <outputs>
            <output
              refId="{comp_ref}.Outputs[OLE DB Destination Error Output]"
              exclusionGroup="1"
              isErrorOut="true"
              name="OLE DB Destination Error Output"
              synchronousInputId="{comp_ref}.Inputs[OLE DB Destination Input]">
              <outputColumns>
                <outputColumn
                  refId="{comp_ref}.Outputs[OLE DB Destination Error Output].Columns[ErrorCode]"
                  dataType="i4"
                  lineageId="{comp_ref}.Outputs[OLE DB Destination Error Output].Columns[ErrorCode]"
                  name="ErrorCode"
                  specialFlags="1" />
                <outputColumn
                  refId="{comp_ref}.Outputs[OLE DB Destination Error Output].Columns[ErrorColumn]"
                  dataType="i4"
                  lineageId="{comp_ref}.Outputs[OLE DB Destination Error Output].Columns[ErrorColumn]"
                  name="ErrorColumn"
                  specialFlags="2" />
              </outputColumns>
            </output>
          </outputs>
        </component>'''


def dft_xml(parent_ref: str, dft: DFT) -> str:
    """Tache Data Flow complete (Source + Destination + Path)."""
    dft_ref = f"{parent_ref}\\{dft.name}"
    if dft.source_kind == "odbc":
        src_xml = odbc_source_component(dft_ref, dft)
        src_name = "ODBC Source"
    else:
        src_xml = oledb_source_component(dft_ref, dft)
        src_name = "OLE DB Source"
    dest_xml = oledb_destination_component(dft_ref, dft, src_name)

    src_output = f"{dft_ref}\\{src_name}.Outputs[{src_name} Output]"
    dest_input = f"{dft_ref}\\OLE DB Destination.Inputs[OLE DB Destination Input]"
    path_name  = "Source Output to Destination"

    return f'''      <DTS:Executable
        DTS:refId="{dft_ref}"
        DTS:CreationName="Microsoft.Pipeline"
        DTS:Description="Data Flow Task"
        DTS:DTSID="{guid("dft", dft.name)}"
        DTS:ExecutableType="Microsoft.Pipeline"
        DTS:LocaleID="-1"
        DTS:ObjectName="{dft.name}"
        DTS:TaskContact="Performs high-performance data extraction, transformation and loading;Microsoft Corporation; Microsoft SQL Server; (c) Microsoft Corporation; All Rights Reserved; http://www.microsoft.com/sql/support/default.asp;0">
        <DTS:Variables />
        <DTS:ObjectData>
          <pipeline version="1">
            <components>
{src_xml}
{dest_xml}
            </components>
            <paths>
              <path
                refId="{dft_ref}.Paths[{path_name}]"
                endId="{dest_input}"
                name="{path_name}"
                startId="{src_output}" />
            </paths>
          </pipeline>
        </DTS:ObjectData>
      </DTS:Executable>'''


def sequence_xml(parent_ref: str, name: str, children_xml: str,
                 precedences_xml: str) -> str:
    """Sequence Container."""
    ref = f"{parent_ref}\\{name}"
    return f'''    <DTS:Executable
      DTS:refId="{ref}"
      DTS:CreationName="STOCK:SEQUENCE"
      DTS:Description="Sequence Container"
      DTS:DTSID="{guid("seq", ref)}"
      DTS:ExecutableType="STOCK:SEQUENCE"
      DTS:LocaleID="-1"
      DTS:ObjectName="{name}">
      <DTS:Variables />
      <DTS:Executables>
{children_xml}
      </DTS:Executables>
      <DTS:PrecedenceConstraints>
{precedences_xml}
      </DTS:PrecedenceConstraints>
    </DTS:Executable>'''


# ----- Composition du Control Flow ---------------------------------------------

# SQL des Execute SQL Task
SQL_LIRE_WATERMARK = (
    "SELECT ISNULL(MAX(last_value), '1900-01-01') "
    "FROM etl.watermark WHERE job_name = 'fait_ventes';"
)

SQL_TRUNCATE_STAGING = "; ".join([
    "TRUNCATE TABLE staging.geographie_full",
    "TRUNCATE TABLE staging.fournisseur_full",
    "TRUNCATE TABLE staging.canal",
    "TRUNCATE TABLE staging.produit_full",
    "TRUNCATE TABLE staging.client_full",
    "TRUNCATE TABLE staging.employe_full",
    "TRUNCATE TABLE staging.lignes_commande",
]) + ";"

SQL_EXEC_RUN_PIPELINE = "EXEC etl.sp_run_pipeline;"

SQL_TRUNCATE_DWH = "; ".join([
    "TRUNCATE TABLE dw.fait_ventes",
    "TRUNCATE TABLE dw.dim_client",
    "TRUNCATE TABLE dw.dim_employe",
    "TRUNCATE TABLE dw.dim_produit",
    "TRUNCATE TABLE dw.dim_fournisseur",
    "TRUNCATE TABLE dw.dim_geographie",
    "TRUNCATE TABLE dw.dim_canal",
    "TRUNCATE TABLE dw.dim_date",
]) + ";"


def build_chargement_staging() -> str:
    parent = "Package\\SEQ_Pipeline_Complet\\SEQ_Chargement_Staging"

    # Children
    trunc = sql_task_xml(parent, "SQL_Truncate_Staging",
                         "OrionETL_CM", SQL_TRUNCATE_STAGING)

    # 6 DFT en parallele
    dims = STAGING_DFTS[:6]   # geo, fourn, canal, produit, client, employe
    lc   = STAGING_DFTS[6]    # lignes_commande

    dft_blocks = [dft_xml(parent, d) for d in STAGING_DFTS]

    # Precedences :
    #   SQL_Truncate_Staging -> 6 DFT (success)
    #   6 DFT -> Lignes_Commande (success, logical AND)
    pcs = []
    for d in dims:
        pcs.append(precedence_xml(parent, "SQL_Truncate_Staging", d.name, logical_and=False))
    for d in dims:
        pcs.append(precedence_xml(parent, d.name, lc.name, logical_and=True))

    return sequence_xml("Package\\SEQ_Pipeline_Complet",
                       "SEQ_Chargement_Staging",
                       trunc + "\n" + "\n".join(dft_blocks),
                       "\n".join(pcs))


def build_push_dwh() -> str:
    parent = "Package\\SEQ_Pipeline_Complet\\SEQ_Push_DWH"

    trunc = sql_task_xml(parent, "SQL_Truncate_DWH",
                         "OrionDWH_CM", SQL_TRUNCATE_DWH)

    # 7 DFT dimensions en parallele, puis FaitVentes
    dims  = DWH_DFTS[:7]      # DimDate, DimCanal, DimGeographie, DimFournisseur,
                              # DimProduit, DimClient, DimEmploye
    fact  = DWH_DFTS[7]       # FaitVentes

    dft_blocks = [dft_xml(parent, d) for d in DWH_DFTS]

    pcs = []
    for d in dims:
        pcs.append(precedence_xml(parent, "SQL_Truncate_DWH", d.name, logical_and=False))
    for d in dims:
        pcs.append(precedence_xml(parent, d.name, fact.name, logical_and=True))

    return sequence_xml("Package\\SEQ_Pipeline_Complet",
                       "SEQ_Push_DWH",
                       trunc + "\n" + "\n".join(dft_blocks),
                       "\n".join(pcs))


def build_seq_pipeline_complet() -> str:
    parent = "Package\\SEQ_Pipeline_Complet"

    chargement = build_chargement_staging()
    exec_sp    = sql_task_xml(parent, "SQL_Exec_sp_run_pipeline",
                              "OrionETL_CM", SQL_EXEC_RUN_PIPELINE)
    push       = build_push_dwh()

    children = chargement + "\n" + exec_sp + "\n" + push

    pcs = [
        precedence_xml(parent, "SEQ_Chargement_Staging", "SQL_Exec_sp_run_pipeline",
                       logical_and=False),
        precedence_xml(parent, "SQL_Exec_sp_run_pipeline", "SEQ_Push_DWH",
                       logical_and=False),
    ]

    return sequence_xml("Package", "SEQ_Pipeline_Complet",
                        children, "\n".join(pcs))


# ----- Assemblage final --------------------------------------------------------

def build_package() -> str:
    now = _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds")
    pkg_dtsid = guid("package", "Orion_Pipeline_Quotidien")

    sql_lire = sql_task_xml(
        "Package", "SQL_Lire_Watermark", "OrionETL_CM", SQL_LIRE_WATERMARK,
        result_set="SingleRow",
        result_bindings=[("0", "User::Watermark")],
    )
    seq = build_seq_pipeline_complet()

    pkg_pcs = [
        precedence_xml("Package", "SQL_Lire_Watermark", "SEQ_Pipeline_Complet",
                       logical_and=False),
    ]

    return f'''<?xml version="1.0" encoding="UTF-8"?>
<DTS:Executable
  xmlns:DTS="www.microsoft.com/SqlServer/Dts"
  DTS:refId="Package"
  DTS:CreationDate="{now}"
  DTS:CreationName="Microsoft.Package"
  DTS:CreatorComputerName="ORION-WIN"
  DTS:CreatorName="generator"
  DTS:DTSID="{pkg_dtsid}"
  DTS:ExecutableType="Microsoft.Package"
  DTS:LastModifiedProductVersion="16.0.5026.0"
  DTS:LocaleID="1036"
  DTS:ObjectName="Orion_Pipeline_Quotidien"
  DTS:PackageType="5"
  DTS:VersionBuild="1"
  DTS:VersionGUID="{guid("pkg_version", "Orion_Pipeline_Quotidien")}">
  <DTS:Property DTS:Name="PackageFormatVersion">8</DTS:Property>
  <DTS:ConnectionManagers>
{cm_xml()}
  </DTS:ConnectionManagers>
{variables_xml()}
  <DTS:Executables>
{sql_lire}
{seq}
  </DTS:Executables>
  <DTS:PrecedenceConstraints>
{chr(10).join(pkg_pcs)}
  </DTS:PrecedenceConstraints>
</DTS:Executable>
'''


def main() -> None:
    xml = build_package()
    with open(OUT, "w", encoding="utf-8") as f:
        f.write(xml)
    print(f"OK -> {OUT}")
    print(f"     {sum(1 for _ in xml.splitlines())} lignes, "
          f"{len(xml.encode('utf-8')):,} octets")


if __name__ == "__main__":
    main()
